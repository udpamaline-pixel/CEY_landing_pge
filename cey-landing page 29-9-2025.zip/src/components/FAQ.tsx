import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { HelpCircle } from 'lucide-react';

const FAQ = () => {
  const faqs = [
    {
      question: "How long does a transfer take?",
      answer: "Most transfers are completed within minutes. Bank transfers may take 1-3 business days depending on the destination country and recipient bank processing times."
    },
    {
      question: "Are there any fees?",
      answer: "We charge a small, transparent fee starting from $2.99 per transfer. Our fees are clearly displayed before you confirm your transfer, with no hidden charges ever."
    },
    {
      question: "Is my money secure?",
      answer: "Absolutely. We use bank-level encryption, are regulated by financial authorities, and partner with trusted banks worldwide. Your funds are protected throughout the entire transfer process."
    },
    {
      question: "What currencies do you support?",
      answer: "We support over 150 currencies across 200+ countries. Popular currencies include USD, EUR, GBP, INR, JPY, AUD, CAD, and many more."
    },
    {
      question: "How can I track my transfer?",
      answer: "You'll receive a unique tracking number via email and SMS. You can track your transfer in real-time through our website or mobile app using this reference number."
    },
    {
      question: "What documents do I need?",
      answer: "You'll need a valid government-issued ID and proof of address. For larger transfers, additional documentation may be required for compliance with international regulations."
    },
    {
      question: "Can I cancel a transfer?",
      answer: "Yes, you can cancel a transfer if it hasn't been paid out to the recipient yet. Contact our customer support immediately, and we'll process your cancellation and refund."
    },
    {
      question: "What are your exchange rates?",
      answer: "We offer competitive exchange rates that are updated in real-time. Our rates include a small margin, which is how we keep our transfer fees low while maintaining excellent service."
    }
  ];

  return (
    <section id="faqs" className="py-20 lg:py-20 bg-background">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-heading font-bold text-3xl md:text-4xl lg:text-5xl text-foreground mb-6">
            Frequently Asked <span className="text-gradient">Questions</span>
          </h2>
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
            Find answers to common questions about our international money transfer services.
          </p>
        </div>

        <div className="max-w-3xl mx-auto">
          <div className="flex items-center justify-center gap-3 mb-8">
            <HelpCircle className="text-primary" size={32} />
            <span className="font-heading font-bold text-xl text-foreground">
              Help Center
            </span>
          </div>

          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem 
                key={index} 
                value={`item-${index}`}
                className="border border-border rounded-lg px-6 shadow-[var(--shadow-card)] bg-card/50 backdrop-blur-sm"
              >
                <AccordionTrigger className="text-left font-heading font-semibold text-lg hover:text-primary">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground leading-relaxed pt-2 pb-4">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>

          {/* Still have questions CTA */}
          <div className="text-center mt-12 p-8 bg-gradient-to-r from-accent/50 to-primary/10 rounded-xl">
            <h3 className="font-heading font-bold text-xl mb-4">
              Still have questions?
            </h3>
            <p className="text-muted-foreground mb-6">
              Our customer support team is available 24/7 to help you with any questions or concerns.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="bg-primary text-primary-foreground hover:bg-primary/90 px-6 py-3 rounded-lg font-medium transition-colors">
                Contact Support
              </button>
              <button className="border border-primary text-primary hover:bg-primary hover:text-primary-foreground px-6 py-3 rounded-lg font-medium transition-colors">
                Live Chat
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FAQ;