import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { ArrowUpDown, Calculator } from 'lucide-react';

const CurrencyCalculator = () => {
  const [amount, setAmount] = useState('100');
  const [fromCurrency, setFromCurrency] = useState('USD');
  const [toCurrency, setToCurrency] = useState('EUR');

  // Sample exchange rates (in a real app, this would come from an API)
  const exchangeRates: { [key: string]: { [key: string]: number } } = {
    USD: { EUR: 0.85, GBP: 0.73, INR: 83.15, JPY: 149.50 },
    EUR: { USD: 1.18, GBP: 0.86, INR: 97.71, JPY: 175.99 },
    GBP: { USD: 1.37, EUR: 1.16, INR: 113.72, JPY: 204.65 },
    INR: { USD: 0.012, EUR: 0.010, GBP: 0.0088, JPY: 1.80 },
    JPY: { USD: 0.0067, EUR: 0.0057, GBP: 0.0049, INR: 0.56 }
  };

  const currencies = [
    { code: 'USD', name: 'US Dollar', flag: '🇺🇸' },
    { code: 'EUR', name: 'Euro', flag: '🇪🇺' },
    { code: 'GBP', name: 'British Pound', flag: '🇬🇧' },
    { code: 'INR', name: 'Indian Rupee', flag: '🇮🇳' },
    { code: 'JPY', name: 'Japanese Yen', flag: '🇯🇵' }
  ];

  const calculateResult = () => {
    const rate = exchangeRates[fromCurrency]?.[toCurrency] || 1;
    return (parseFloat(amount) * rate).toFixed(2);
  };

  const swapCurrencies = () => {
    const temp = fromCurrency;
    setFromCurrency(toCurrency);
    setToCurrency(temp);
  };

  const fees = (parseFloat(amount) * 0.01).toFixed(2); // 1% fee
  const totalReceived = (parseFloat(calculateResult()) - parseFloat(fees)).toFixed(2);

  return (
    <section id="calculator" className="py-20 lg:py-20 bg-gradient-to-br from-accent/30 to-background">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-heading font-bold text-3xl md:text-4xl lg:text-5xl text-foreground mb-6">
            Currency <span className="text-gradient">Calculator</span>
          </h2>
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
            Get real-time exchange rates and see exactly how much your recipient will receive.
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <Card className="shadow-[var(--shadow-elegant)] border-0 bg-card/50 backdrop-blur-sm">
            <CardHeader className="text-center pb-8">
              <CardTitle className="flex items-center justify-center gap-3 text-2xl font-heading">
                <Calculator className="text-primary" size={28} />
                Transfer Calculator
              </CardTitle>
            </CardHeader>
            
            <CardContent className="space-y-8">
              {/* Amount Input */}
              <div className="space-y-2">
                <Label htmlFor="amount" className="text-base font-medium">
                  Amount to Send
                </Label>
                <Input
                  id="amount"
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="text-2xl font-bold h-14 text-center"
                  placeholder="100"
                />
              </div>

              {/* Currency Selection */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-end">
                <div className="space-y-2">
                  <Label className="text-base font-medium">From</Label>
                  <Select value={fromCurrency} onValueChange={setFromCurrency}>
                    <SelectTrigger className="h-12">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {currencies.map((currency) => (
                        <SelectItem key={currency.code} value={currency.code}>
                          <div className="flex items-center gap-2">
                            <span>{currency.flag}</span>
                            <span>{currency.code}</span>
                            <span className="text-muted-foreground">- {currency.name}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex justify-center">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={swapCurrencies}
                    className="rounded-full w-12 h-12 p-0"
                  >
                    <ArrowUpDown size={16} />
                  </Button>
                </div>

                <div className="space-y-2">
                  <Label className="text-base font-medium">To</Label>
                  <Select value={toCurrency} onValueChange={setToCurrency}>
                    <SelectTrigger className="h-12">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {currencies.map((currency) => (
                        <SelectItem key={currency.code} value={currency.code}>
                          <div className="flex items-center gap-2">
                            <span>{currency.flag}</span>
                            <span>{currency.code}</span>
                            <span className="text-muted-foreground">- {currency.name}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Results */}
              <div className="bg-gradient-to-r from-primary/10 to-primary-dark/10 rounded-xl p-6 space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Exchange Rate:</span>
                  <span className="font-bold">
                    1 {fromCurrency} = {exchangeRates[fromCurrency]?.[toCurrency]?.toFixed(4) || '1.0000'} {toCurrency}
                  </span>
                </div>
                
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Transfer Fee:</span>
                  <span className="font-bold">{fees} {fromCurrency}</span>
                </div>
                
                <div className="border-t pt-4">
                  <div className="flex justify-between items-center">
                    <span className="text-lg font-medium">Recipient Receives:</span>
                    <span className="text-2xl font-bold text-primary">
                      {totalReceived} {toCurrency}
                    </span>
                  </div>
                </div>
              </div>

              {/* Action Button */}
              <Button className="w-full btn-primary text-lg py-6 font-bold uppercase tracking-wide">
                Start Transfer
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default CurrencyCalculator;